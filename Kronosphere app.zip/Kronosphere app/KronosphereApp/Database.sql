-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: kronosphere
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backup_files`
--

DROP TABLE IF EXISTS `backup_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_files` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `File_Name` varchar(255) NOT NULL,
  `File_Size` bigint(20) NOT NULL,
  `File_Content` longblob NOT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_files`
--

LOCK TABLES `backup_files` WRITE;
/*!40000 ALTER TABLE `backup_files` DISABLE KEYS */;
INSERT INTO `backup_files` VALUES (1,'sadsadd.txt',15,_binary 'asdasdasdsadsad','2023-11-22 17:44:40');
/*!40000 ALTER TABLE `backup_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `information_files`
--

DROP TABLE IF EXISTS `information_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `information_files` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `File_Name` varchar(255) NOT NULL,
  `Path` varchar(1000) NOT NULL,
  `Encryption_Key` varchar(255) NOT NULL,
  `File_Size` bigint(20) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `information_files`
--

LOCK TABLES `information_files` WRITE;
/*!40000 ALTER TABLE `information_files` DISABLE KEYS */;
INSERT INTO `information_files` VALUES (1,'safasghjtjrtjtr.txt','C:\\Users\\lhevy\\OneDrive\\Desktop\\New Encryption Software Backup (1)\\New Encryption Software\\Kronosphere\\Decrypted Files\\safasghjtjrtjtr.txt','QSgD+Ich4aKzUFkgIYAsCzcVF5Crjqm7vYoKOebluQ0=',14,'2023-11-24');
/*!40000 ALTER TABLE `information_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keymanagerpassword`
--

DROP TABLE IF EXISTS `keymanagerpassword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `keymanagerpassword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keymanagerpassword`
--

LOCK TABLES `keymanagerpassword` WRITE;
/*!40000 ALTER TABLE `keymanagerpassword` DISABLE KEYS */;
INSERT INTO `keymanagerpassword` VALUES (1,'Secretary','Jollibee');
/*!40000 ALTER TABLE `keymanagerpassword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recyclebin`
--

DROP TABLE IF EXISTS `recyclebin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recyclebin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(1000) DEFAULT NULL,
  `deletion_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recyclebin`
--

LOCK TABLES `recyclebin` WRITE;
/*!40000 ALTER TABLE `recyclebin` DISABLE KEYS */;
INSERT INTO `recyclebin` VALUES (5,'New Text Document (2).txt','C:\\Users\\lhevy\\OneDrive\\Desktop\\New Encryption Software Backup (1)\\New Encryption Software\\Kronosphere\\Recycle Bin\\New Text Document (2).txt','2023-11-23 15:27:09'),(6,'asdasdsad.txt','C:\\Users\\lhevy\\OneDrive\\Desktop\\New Encryption Software Backup (1)\\New Encryption Software\\Kronosphere\\Recycle Bin\\asdasdsad.txt','2023-11-25 08:26:16'),(7,'3v3.lnk','C:\\Users\\lhevy\\OneDrive\\Desktop\\New Encryption Software Backup (1)\\New Encryption Software\\Kronosphere\\Recycle Bin\\3v3.lnk','2023-11-28 05:15:09'),(8,'4v4.lnk','C:\\Users\\lhevy\\OneDrive\\Desktop\\New Encryption Software Backup (1)\\New Encryption Software\\Kronosphere\\Recycle Bin\\4v4.lnk','2023-11-28 05:15:16');
/*!40000 ALTER TABLE `recyclebin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_table`
--

DROP TABLE IF EXISTS `user_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `user_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_table`
--

LOCK TABLES `user_table` WRITE;
/*!40000 ALTER TABLE `user_table` DISABLE KEYS */;
INSERT INTO `user_table` VALUES (1,'Secretary','jollibee','Secretary'),(2,'Staff','hashtag','Staff');
/*!40000 ALTER TABLE `user_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-28 16:37:06
